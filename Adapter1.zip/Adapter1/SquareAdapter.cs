﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter1
{
    public class SquareAdapter : IShape
    {
        private readonly Square _square;

        public SquareAdapter(Square square)
        {
            _square = square;
        }

        public double GetArea()
        {
            
            return Math.Pow(_square.GetSideLength(), 2);
        }
    }

}
