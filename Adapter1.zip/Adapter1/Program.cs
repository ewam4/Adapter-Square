﻿using Adapter1;
namespace Adapter1
{
    class Program
    {
        static void Main(string[] args)
        {
            Square square = new Square(5);
            SquareAdapter adapter = new SquareAdapter(square);

            Console.WriteLine(adapter.GetArea()); 
        }
    }
}